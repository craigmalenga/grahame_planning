my cousin is asking me to help with a planning application the stuff he sent me is as a message below then all attachments ("im looking to create" come back with any list of questions you hjave or push ahead and answer his first draft pleas e top level qualirtty... he is ceo to the firm i work for and we need him to sell this house to fund my salary!!!

---

first message from him but has been superseded to include a bathroom tweak and more info on the exterior stairs / dimensions and the internal wall doorway to become openning

but this is the first message
I’m looking to create the detailed plans, elevations and sections for Flat 1, 20 Hornton Street.

At this stage I do not need you to prepare the full planning application package. I mainly need your help producing the proper measured existing and proposed drawings so we can review the design clearly and then use the drawings for planning/building control if required.

The scope is the rear elevation/lightwell area, plus the internal opening between the two principal ground floor reception rooms.

Overall design intention

The proposal should be drawn as a restrained, sympathetic and restorative improvement to the rear of the property.

The rear lightwell/courtyard is to remain open. I am not looking to cover over, infill or overdevelop the rear space.

The drawings should show a cleaner and more coherent rear elevation, with:

better access to the rear/lightwell area;

tidier pipework and external services;

improved/reinstated fenestration;

a lightweight reclaimed Victorian cast iron spiral staircase;

sensitive making good to the existing rear façade.

The idea is that the rear elevation should look more ordered, more traditional and more attractive than the existing condition, not like another bulky rear intervention.

Existing drawings required

Please prepare the following existing drawings from measurement/survey:

Existing ground floor plan

Please show:

front ground floor reception room;

rear ground floor reception room;

existing opening between the two reception rooms;

existing rear wall/opening/door arrangement;

relationship to the rear lightwell/courtyard;

stairs/internal circulation where relevant;

existing windows and doors;

wall thicknesses;

key dimensions.

Please dimension the existing opening between the front and rear reception rooms clearly, including:

width;

height if available;

nib returns either side;

distance from adjacent walls/chimney breasts/features;

any visible structural/support condition.

Existing lower ground floor plan

Please show:

lower ground layout;

rear lightwell/courtyard relationship;

existing rear access/openings;

position of any lower ground rear doors/windows;

external steps/levels where relevant;

vaults or rear/lower ground spaces where relevant;

existing drainage, downpipes or external services visible from the rear;

key dimensions and levels.

Existing rear elevation

This is important.

Please show the current rear elevation accurately, including:

all existing windows;

all existing doors/openings;

the existing rear opening to be altered/enlarged;

the existing window to be extended by approximately 400mm;

the blocked-up former rear window/opening;

existing pipework, downpipes, rainwater goods and external services;

existing sills, heads, lintels, reveals and any visible brick/render detailing;

existing lightwell/courtyard floor level;

ground/lower ground relationship;

existing parapets, walls, railings or boundaries where relevant.

Please mark clearly:

“existing window opening to be extended by approx. 400mm”;

“previously blocked-up rear window/opening to be reinstated”;

“existing rear access/opening to be enlarged/altered”;

“existing pipework/services to be rationalised”.

Existing section through rear lightwell/courtyard

Please provide at least one section through the rear lightwell/courtyard showing:

lower ground floor level;

ground floor level;

rear lightwell/courtyard level;

existing rear openings;

height difference to be served by the spiral staircase;

relationship between proposed staircase position and existing doors/windows;

boundary walls if relevant;

any landing/platform condition if already obvious;

head heights and threshold levels where relevant.

Existing internal elevation/section of reception-room opening

Please show the existing opening between the two principal ground floor reception rooms.

This can be an internal elevation, section or enlarged plan detail.

Please include:

existing opening width;

existing opening height;

wall thickness;

nibs/returns;

relationship to skirting, cornice, ceiling, chimney breast or other period features;

any visible signs of previous alteration;

any structural assumptions to be checked by engineer.

Proposed drawings required

Proposed ground floor plan

Please show:

the enlarged opening between the front and rear reception rooms;

proposed opening width and height;

indicative structural support/beam zone, marked subject to structural engineer confirmation;

making good to walls, plaster, skirting, cornicing and finishes;

rear elevation changes as they affect the ground floor;

proposed rear access/door arrangement;

relationship to the proposed spiral staircase and rear lightwell/courtyard.

Please show the reception-room opening as a principal internal improvement, not as a full reconfiguration. The plan should make clear that the residential use and main layout remain essentially the same.

Proposed lower ground floor plan

Please show:

proposed spiral staircase position in the rear lightwell/courtyard;

relationship of the staircase to lower ground access and rear area;

any proposed landing/platform if required;

clearance around the staircase;

relationship to doors/windows;

proposed reinstated rear window/opening where relevant;

proposed external services/pipework route;

any drainage or lightwell floor implications if relevant.

Proposed rear elevation

This is the key drawing.

Please show:

the reclaimed Victorian cast iron spiral staircase installed in the rear lightwell/courtyard;

the altered/enlarged rear access/opening with proposed glazed doors/access;

the existing rear window extended by approximately 400mm;

the previously blocked-up rear window/opening reinstated;

rationalised/repositioned downpipes/rainwater goods/external services;

making good and repair to surrounding façade;

matching sill/head/reveal details where appropriate;

any new lintel/support zone, marked subject to structural engineer confirmation;

dark painted/black painted metal finish to the spiral staircase;

traditional/sympathetic door and window detailing.

Please make the elevation read as a coherent improvement. The staircase should appear lightweight and traditional, not bulky. The windows/openings should look properly proportioned and consistent with the rear elevation.

Proposed section through rear lightwell/courtyard

Please show:

the proposed spiral staircase in section;

lower ground/lightwell floor level;

ground floor/rear threshold level;

total rise to be achieved;

number/rhythm of treads if known;

central pole position;

landing/platform if required;

relationship to rear doors/access;

relationship to the extended/reinstated windows;

clearances/headroom;

boundary walls and adjacent levels where relevant;

fixing/support principle if possible.

Please use the actual staircase dimensions as far as we know them:

central pole approximately 3.3m high;

approximately 15 treads;

tread rise around 200–205mm;

overall rise likely around 3.0m, subject to final measurement and platform/landing design.

If the staircase does not exactly meet the threshold, please show the likely need for a small landing/platform or adjustment piece rather than forcing the drawing.

Proposed detail of spiral staircase

Please provide a simple enlarged detail or annotated drawing showing:

position in the lightwell/courtyard;

diameter/footprint if measured;

central pole;

tread arrangement;

handrail/balustrade;

top landing/platform connection if needed;

bottom fixing/base plate/foundation principle;

wall fixings if any;

painted cast iron/metal finish;

note: “final fixing/structural detail subject to engineer/installer confirmation”.

The staircase should be labelled as:

Reclaimed Victorian cast iron spiral staircase, restored and finished in dark painted metal/black painted ironwork.

Proposed detail of rear access/doors

Please show:

existing opening line;

proposed enlarged/altered opening;

door configuration;

threshold level;

materials;

glazing arrangement;

relationship to staircase/landing;

making good to surrounding masonry/render;

any lintel/support note.

The proposed doors should be drawn sympathetically. I do not want anything that looks like a crude modern insertion.

Proposed detail of 400mm window extension

Please show:

existing window opening;

proposed extension by approximately 400mm;

direction of extension, likely downward if that is the design intention;

new sill/head/reveal treatment;

matching masonry/render making good;

any lintel or structural note;

relationship to any nearby pipework.

Please label:

Existing rear window opening to be extended by approximately 400mm, with matching reveals, sill/head treatment and making good to surrounding façade.

Proposed detail of reinstated blocked-up window

Please show:

the blocked-up opening as existing;

the reinstated window as proposed;

proposed frame style/material;

sill/head/reveal detail;

matching proportions to rear elevation;

making good to surrounding fabric;

any structural/lintel note.

Please frame this as:

Reinstatement of previously blocked-up former rear window opening.

The important point is that this should look like a restoration of a former opening, not a random new opening.

Proposed internal opening between reception rooms

Please provide an enlarged proposed plan/elevation/section showing:

existing opening line faintly/dashed;

proposed enlarged opening;

final proposed width;

final proposed height;

retained wall nibs/returns;

indicative beam/support zone;

relationship to ceiling/cornice/skirting;

making good to plaster, joinery and finishes;

note: “subject to structural engineer design and Building Control approval where required”.

Please show this as a careful internal alteration that improves the relationship between the principal rooms while preserving/restoring period detailing around the opening.

Dimensions and survey information to capture

Please measure and include:

overall ground floor room dimensions;

overall lower ground/rear area dimensions;

existing opening between reception rooms;

proposed opening target size if we agree it on site;

floor-to-ceiling heights;

wall thicknesses;

rear elevation window sizes;

rear door/opening sizes;

height from lower lightwell/courtyard level to ground/rear threshold;

lightwell/courtyard width and depth;

staircase available footprint;

distance from proposed staircase to doors/windows/boundaries;

pipework positions;

drainage positions if visible;

blocked-up window dimensions;

window to be extended dimensions;

level changes and threshold heights.

Notes to include on drawings

Please include suitable notes such as:

“Existing rear lightwell/courtyard retained as open external space.”

“Reclaimed Victorian cast iron spiral staircase proposed, restored and finished in dark painted metal.”

“Existing rear window opening extended by approximately 400mm.”

“Previously blocked-up rear window opening reinstated.”



------

see chatgpt attempt 1 which missed the brief

---

my message to chat was 

he asked for a door widening to be an opening in the internal building also and needs an elevation for this in the planning permission --- analyse image carefully... also, can you not see that in theimages so far produced that whilst they look visually nice... they are wrong... you have moved what is an lshape corner in a courtyard to a flat wall in the prohections the spiral staircase has to be in the corner or mid way between those two walls as per the photo --- mirror image of this picture attached given it has a different l;eft to right rather trhan right to left L shape --- the elevations at this stage more important (internal and out) than the wording for application please rework internal and exteranal el;eations

---

see chatgpt attempt 2 which missed the brief

---

then i said

give me a 3d renderinging not a photo realistic to start... you are missing the point for the layout it is a wall on the left with a window below and a window above... t then 90 degree angle then a doouble door below with windows and above a large window --- the plan is presented with the left hand side getting the window above lowered to be floor height and make it a doiorway for the staircase... the staircase spirals down in that cortner can you not understand difference

--- see chatgpt attempt 3 which missed the brief (but getting closer 3d)

then message from my cousin
message from the ceo / my cousin (im craig - he is grahame)


then other photos files

Hi Craig,



I’m pulling together some of the key rear elevation and lower basement measurements for the Hornton Street plans.



Starting with the very rear wall, where the wide lower-basement doors are:



The two rear doors are symmetrical, at 72 cm each side.



Facing the rear doors from inside, there is a small protruding section of wall on the right-hand side, higher up the wall, roughly around 2 metres up. I will send a photograph so this is clear.



The sill height is 80 cm.



The doorway/opening up to the small wooden balustrade elements is 82 cm wide.



The overall width of the full rear opening/recess is 185 cm.



The height to the white line above is 290 cm.



Separately, on the wall with the two rear openings — including the existing bricked-up opening — the horizontal measurements from left to right are as follows:



51 cm solid wall

60 cm width of the bricked-up former window/opening

49 cm solid pier between openings

123 cm width of the existing larger window

17 cm to the end of the wall



Under both sills, the height is 90 cm.



Both window/opening heights are 160 cm.



One thing to note is the sill height comparison. The existing kitchen window, which we are proposing to convert into a door, has a height to sill, including the sill itself, of approximately 372 cm. The rear windows are slightly higher, at approximately 380 cm to the sill. So there is a small but noticeable difference in level between these openings.



The key planning/design points are:



The bricked-up former opening should be shown as a reinstated window/opening, because the existing fabric suggests it was historically present.



The existing kitchen window is proposed to be extended downwards and converted into a door.



The rear elevation should show the existing asymmetry and the actual measured positions, rather than assuming the openings are evenly spaced.



I will send photographs to help identify the protruding wall section, the sill lines, the bricked-up opening, and the white line height.


---

Add this further section for Craig:







Further internal measurements for the ground-floor front lounge/reception rooms:



In the front lounge, on the fireplace wall, facing towards the front of the house, the approximate breakdown is:



190 cm + 180 cm + 190 cm



So the wall is broadly balanced around the fireplace, subject to final survey.



Because of the hallway and internal layout, the side dimensions of this room are slightly irregular.



On the far left-hand wall, the approximate measurements are:



70 cm wall section

112 cm cut-out/opening

265 cm total wall length



Moving through the doorway into the adjoining rear reception/kitchen-facing room, the corresponding side appears to have approximately:



60 to 70 cm wall section

112 cm opening/cut-out

150 cm wall section

Then the dividing wall that is proposed to be removed or opened up

Then approximately 140 cm on the other side



The internal wall itself appears to be approximately 10 cm thick.



Overall, the rear room appears to be roughly 300 cm across on that side, and around 35 cm wider than the front room, because of the way the hallway reduces the usable width of the front lounge.



On the left-hand wall, when facing towards the garden/rear of the house, the approximate fireplace wall breakdown is:



145 cm wall section

184 cm fireplace

146 cm wall section



On the rear-facing wall/window wall:



There is approximately 40 cm between the relevant side wall/opening and the window.



The rear-facing window is approximately:



210 cm wide



The window height is approximately:



300 cm to 310 cm high



The sill height is approximately:



80 cm from floor level



Then there is approximately 70 cm beyond the window, although this includes/relates to the end pier or pillar.



If the dividing wall is taken down or opened up, this then creates a wider connection through into the kitchen/rear room area. So for the proposed plan, it is important to show not just the present room separation, but also the potential width and alignment once that internal wall is removed or substantially opened.



The key point is that the rear reception/kitchen-facing room is slightly wider than the front lounge, by approximately 35 cm, and the proposed opening needs to account for that difference so the final layout feels aligned and intentional rather than awkward.


I would like to make the gap in between the rooms 70 on one side and 60 on the Other with 290 to  3 m height 

---

Add this kitchen and proposed shower room section for Craig:







Further measurements and proposed layout for the kitchen/rear room:



The kitchen is approximately 240 cm wide.



The ceiling height is approximately 245 cm.



The existing small window/opening intended to become a door down to the spiral staircase option has an actual window gap of approximately 66 cm, although the full structural recess/receptacle is wider.



The sill height of this opening is approximately 72 cm from the floor.



The total length of the kitchen wall on the window side is approximately 290 cm to the inner part of the door.



The rear door/opening side is approximately 275 cm in total, but the opposite side is only around 250 cm, because the wall is slightly angled.



At the back of the kitchen:



The rear door is approximately 100 cm wide.



The small rear window on the right-hand side of the kitchen is approximately 48 cm wide and 130 cm high.



Within the approximately 250 cm angled wall run, I would like to create a compact shower room/utility arrangement.



The proposed layout is:



A shower on the right-hand side of the proposed new door/opening.



The shower tray is intended to be approximately 100 cm wide, plus the thickness of a new partition wall.



Then a WC and basin within the same compact room.



I would like to use a pocket/sliding door, rather than a conventional outward-opening door, to preserve space.



The toilet may work best backing onto the wall adjoining the kitchen, depending on plumbing and service routing.



I would also like to retain space at the far end for a stacked or side-by-side washing machine/tumble dryer arrangement, likely requiring around 60 cm width.



The concern is that if the full available width is around 250 cm, and around 60 cm is preserved for laundry appliances, this leaves roughly 190 cm for the shower room elements. A 100 cm shower tray plus WC and basin may be tight, but potentially workable if carefully designed with a compact basin, concealed cistern, and sliding/pocket door.



I also have crystal/glazed doors available which are approximately:



124.5 cm wide

224.5 cm high



These may fit neatly into the proposed arrangement, subject to allowing for the new partition wall, shower enclosure, and clearances.



The key design intention is to keep this area compact and efficient, while creating a usable shower room/utility space and still preserving the option for the new door/opening down to the spiral staircase route.



Craig, it would be useful if you could test this properly on plan, particularly:



Whether a 100 cm shower tray, WC and basin can work within the available width.



Whether the laundry appliances can still sit at the end.



Whether a pocket/sliding door can be accommodated.



How thick the new partition wall needs to be.



Whether the glazed/crystal doors at 124.5 cm x 224.5 cm can be incorporated cleanly.



And whether the new door down to the spiral staircase option aligns properly with the existing window/recess.

----

Summary of Victorian spiral staircase measurements



For Craig, the reclaimed cast-iron spiral staircase should be treated as follows:



The staircase has approximately 15 cast-iron treads / pads.



Each tread rise appears to be around 200 mm to 210 mm, giving an estimated total rise of approximately:



3.0 m to 3.15 m



The central pole is approximately 3.3 m high, so it gives some extra height above the final tread / landing level.



The tread / pad projects approximately 80 cm from the centre/inner pole area towards the outer edge.



The diagonal / overall tread depth measurement appears to be approximately 80 cm to 85 cm.



Each tread is approximately 34 cm wide at its widest point.



The likely external diameter of the staircase is approximately:



160 cm



However, for layout and installation purposes, Craig should allow a practical circular envelope of at least:



165 cm to 170 cm



Ideally, if the patio/lightwell allows, assume:



170 cm to 175 cm



This allows for the outer edge, handrail, casting thickness, fixings, tolerance, and the fact that it is an old reclaimed staircase.



The patio/lightwell is approximately 325 cm wide x 295 cm deep, so the staircase should theoretically fit, but Craig needs to test it carefully on plan against the proposed new door, landing/platform height, drainage, wall clearances and usable circulation.



Planning working assumption:

The staircase is likely suitable if the required rise from patio/lightwell level to the proposed upper door/landing is around 2.9 m to 3.1 m. If the actual required height differs materially, a small plinth, landing or platform adjustment may be needed.

---

next two images view and dimenions of door

---

next image for a random reason is a bath 



---

another message 

	Merlyn Ionic Essence Black Hinged Shower Door with Inline Panel 940 x 2000mm - EX Display  £75.00


For upstairs 

---

final image inspect.. not sure relevance

---


--- see chatgpt attempt 4 which missed the brief (but getting closer 3d and plan etc as you need and elevations etc)

---

after this my cousin replied last night wth all the other emails and files
can you read them, all meticulously... multiple agents to review each to come to conclusions

i want 2d quality elevants for the courtyard (the left hand and right hand of the l shape corner separately with all dimensions as an artichect would) / 2d elevations of the bathroom changes and the door widening inside house / 2d diagrams from above of internal walls / for bathrooms and room with wall to be given widening not doorway

then 3d rendering of the outside and bathroom and maybe way widening inside also
---
key this needs to be replicable so if i ask you to tweak something you can
---

note compared to the stuff im getting of chatgpt the dimensions are key as you would expect for planning ...eg the outside space on he right of the lshape where the double door exists on bottom level onto courtyard has an equal disatance from edge of doorway to the left wall as ir does to the right way (chat images always shows the left side much wider where staircase goes)

---

also note that the left hand of the L shape upper floor doesnt have a window... it was bricked in... but needs to be opended / changed to dooway as describe3d.. but this wrong in chapt 3d rendering

---

